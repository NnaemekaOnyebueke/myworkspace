# mypackage
This library  ws created as an example of how to publish python package.

# How to install
1. 